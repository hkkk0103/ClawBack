// hud.js — ClawBack HUD，注入GMGN/DeBot

(() => {
  if (document.getElementById('clawback-hud')) return;

  const PLATFORM = location.hostname.includes('gmgn') ? 'gmgn' : 'debot';
  const TOP_N = 20;
  const SETTINGS_KEY = 'clawback_hud_settings';

  function loadSettings() {
    try { return JSON.parse(localStorage.getItem(SETTINGS_KEY)) || {}; } catch { return {}; }
  }
  function saveSettings(s) { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); }

  let settings = { threshold: 15, opacity: 0.96, scale: 1.0, voice: true, ...loadSettings() };
  let snapshot = {}, currentCA = '', alertCount = 0;
  let minimized = false, settingsOpen = false, isRunning = false;
  let voiceCooldown = {};

  // ── 语音 ──────────────────────────
  speechSynthesis.getVoices();
  speechSynthesis.addEventListener('voiceschanged', () => speechSynthesis.getVoices());

  function speak(rank) {
    if (!settings.voice) return;
    const now = Date.now();
    const key = `rank_${rank}`;
    if (voiceCooldown[key] && now - voiceCooldown[key] < 15000) return;
    voiceCooldown[key] = now;
    speechSynthesis.cancel();
    const msg = new SpeechSynthesisUtterance(`第${rank}名，出货中`);
    msg.lang = 'zh-CN';
    msg.rate = 1.1;
    const zhVoice = speechSynthesis.getVoices().find(v => v.lang.startsWith('zh'));
    if (zhVoice) msg.voice = zhVoice;
    speechSynthesis.speak(msg);
  }

  // ── HUD HTML ──────────────────────
  const hud = document.createElement('div');
  hud.id = 'clawback-hud';
  hud.innerHTML = `
    <div id="cb-header">
      <div id="cb-logo"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABCGlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8wQAELAYMDLl5JUVB7k4KEZFRCuwPGBiBEAwSk4sLGHADoKpv1yBqL+viUYcLcKakFicD6Q9ArFIEtBxopAiQLZIOYWuA2EkQtg2IXV5SUAJkB4DYRSFBzkB2CpCtkY7ETkJiJxcUgdT3ANk2uTmlyQh3M/Ck5oUGA2kOIJZhKGYIYnBncAL5H6IkfxEDg8VXBgbmCQixpJkMDNtbGRgkbiHEVBYwMPC3MDBsO48QQ4RJQWJRIliIBYiZ0tIYGD4tZ2DgjWRgEL7AwMAVDQsIHG5TALvNnSEfCNMZchhSgSKeDHkMyQx6QJYRgwGDIYMZAKbWPz9HbOBQAAADUElEQVR4nI2SXWxTZRzGn/ecs3NO27VdN9ay0lL2FTbnNqOwmKHUzaEOFKKuSowhXojGwOIVF14dG0y4MQE1Eb0xxkiCa8KFBgekCU46NzMR2w0/tqVzs1tgrLRr17Oej/e8XiAGkAv/l0+e53fxfx7gfxyLRPh7JHJfY3myr3VqKCIyxv41DP0TdiFQPdjV8uirvg7HnRAOAFhqj4exCA9KB9o6MrsJIYxdVAQAeCkWo98Odg0MHwlc7A7yY15fUQHAK7cARLjFUjcbycIhqdZ6b2Kmp/PTU+9sID17Vz4YfMa1vrDwbK2DnHJYFGm1iIBbPPLGA02l6K+zR5VwmBdYao9HM4sNklv+8sJoW9Oh4/Jnzf7xydHzX+w//vrh59eYdIzNrjDOQumqXL9ct/bXFiLb+gFEMTICLk8FZpnUCVlXPzzXsa/GSVQqOjb46pq3Ve8/llcfOnh6l5dkwq3eSwdaN599jRWQWSy29W4N9UQBSygT1aiQnCswVY3I7oCz1p6tDbrclxftMf8ju29onuuho199k5v7/WZXrGm4v9Gm0w7BXrhUNloUYETYSHhPmel+rGvZ7W3c5Ohl6QVVXfsjkUgLEz9Mh26USlpfWfU8KRU1TRdoskrmKbOXElN/nkzcrsK48vhTAmfuSEzVnzhz7cWtvamPGkPpK5/8PAc5Y+e0TU47ng64FuPzueYFj51xGsdldevk+wf73iaMgSDd5yKN8dXb3U93QxnWdrx79Zpu9jbMCPPBbsyXt6Df8yPOjS3B6xJpDTX5+BL9/K5FKeGwgCe+s6yhjdsN0zFOJMMqSZQ82BBEktZjJ5kgs8I68sl16y29yOJq5ff/mWQkAj4WI/TNdv/pGkF8eVXVaYOX420iQdkQ0FqlorNUomsZg58zHWfut2miAASRiDD7y/hPVTJr3xYQLalS4ppoCb6lm6yQM7BclgsJu/c57t60ooBEAeuxypmdZVghtwhTp7AqKKXJRZOeSBM6WhDZMF+Ztz5+ZezuHwBcFGDxA53+ryfzv2VWDedAsw05jcJnI8jpHKavm0hlDbRvsuPhoHBYuBMQBRgARi2WTy2bu1q8oo/jhToLRDYsoKhaqHZUoJ3nso1uKcN0feFv39Z3sbZowU0AAAAASUVORK5CYII=" id="cb-logo-img"><span>小龙虾预警</span><div id="cb-status-dot"></div></div>
      <div id="cb-header-btns">
        <button id="cb-voice-btn" title="语音开关">${settings.voice ? '🔊' : '🔇'}</button>
        <button id="cb-settings-btn" title="设置">⚙</button>
        <button id="cb-minimize">−</button>
      </div>
    </div>
    <div id="cb-settings-panel">
      <div class="cb-srow">
        <span>出货阈值</span>
        <div class="cb-sctrl"><input type="range" id="cb-s-threshold" min="5" max="50" step="1" value="${settings.threshold}"><span id="cb-s-threshold-v">${settings.threshold}%</span></div>
      </div>
      <div class="cb-srow">
        <span>透明度</span>
        <div class="cb-sctrl"><input type="range" id="cb-s-opacity" min="0.2" max="1" step="0.05" value="${settings.opacity}"><span id="cb-s-opacity-v">${Math.round(settings.opacity*100)}%</span></div>
      </div>
      <div class="cb-srow">
        <span>缩放</span>
        <div class="cb-sctrl"><input type="range" id="cb-s-scale" min="0.6" max="2.0" step="0.1" value="${settings.scale}"><span id="cb-s-scale-v">${settings.scale}x</span></div>
      </div>
      <div class="cb-srow">
        <span>语音播报</span>
        <label class="cb-toggle"><input type="checkbox" id="cb-s-voice" ${settings.voice?'checked':''}><span class="cb-slider"></span></label>
      </div>
    </div>
    <div id="cb-ca"><span id="cb-ca-val">检测代币中...</span></div>
    <div id="cb-body"><div class="cb-empty">等待持仓数据...</div></div>
    <div id="cb-footer"><span>${PLATFORM.toUpperCase()}</span><span>预警 <span id="cb-alert-count">0</span></span></div>
  `;
  document.body.appendChild(hud);
  // ── 龙虾吉祥物 ────────────────────
  const lobster = document.createElement('img');
  lobster.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAABGCAYAAABxLuKEAAABCGlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8wQAELAYMDLl5JUVB7k4KEZFRCuwPGBiBEAwSk4sLGHADoKpv1yBqL+viUYcLcKakFicD6Q9ArFIEtBxopAiQLZIOYWuA2EkQtg2IXV5SUAJkB4DYRSFBzkB2CpCtkY7ETkJiJxcUgdT3ANk2uTmlyQh3M/Ck5oUGA2kOIJZhKGYIYnBncAL5H6IkfxEDg8VXBgbmCQixpJkMDNtbGRgkbiHEVBYwMPC3MDBsO48QQ4RJQWJRIliIBYiZ0tIYGD4tZ2DgjWRgEL7AwMAVDQsIHG5TALvNnSEfCNMZchhSgSKeDHkMyQx6QJYRgwGDIYMZAKbWPz9HbOBQAAAnVUlEQVR4nO18eZRdVZX3b59zpzfXq3lMVSWVqTIAGQgBkirCqAyipiKIAqKAQivOQ9P6UmD356fthAIalVahVVKIzHNIVYBAIAOZKkmlkhqSmqvePN57zznfH0mwVVCgBde3lr+13nrr3Xfuvef93p7O3vtc4J/4J/6Jf+Kf+P8LSoGUauNKgd7te7e1tfFIS4sWiUTYnx9rA/i7PZ/XoNQfJ/SPRgRg7O/817ytyykFIoJSSjF3/CsfcAvOq1bd9w8BCkSk/r5T/FNEANYOqPevWnZOY1hf2p3xP/vEE0+8BAAXtyy9qJblFnRP2c917ep5Hsd+39uaj/ZWT1AqwojaZab3X5eIQ5f8VPPGFolE2Y9pGj6tNrZqANy3M5E3AYq0tPC1nV3iD5UV3qVWsmNVSAsdpiTKzlxyY32lmL0q7HxmcpeDiiwh39y8Ykt39/NtAO8AxFu+2VsZrJQirCWauuIxv9/+6T4zcLRaTGQcsLKkXf6xUzw11xxduzZC7e3t8q1O5K+hra2N//6+DiFf++8Xh1oXpL9SBueSacKe+2ocuGSuxRAVYvtYcHvOx57Izg7elnqkK94FSBx7vSX8VYk5ZlQjRHTshxKRUipCJdiSLhyou1HkU78Cy/u5zy2h7PaLiXDHxo2dvL39rU/kjbC+DXxNR4cAqkovO7P28pX14vKA7taHgsEQFWzuSkUV/WlyHEfuTtmIh2XCYGzXI4/0OwDc47rE8BbJeVMSoxQYoNQJ+3FCnZy+m1uRfuFxzYpbtl231Wh+aDnWkqS/EzEqAkbtkBctmf+x82rErafNDtXUhDgsnwfZnItcOgNhu8jloQIhg7ZvHcVgmuBlGvqzYmRfxvjeI2su+wHa293jtulNz+uvEqNGvuArqOJ6q/rmbgBQqo0TdQgAUFsX67Rkm5PZ94WLTbXlfq473PGet0KvvnUz0MZOjHu7aGsD7+iA+GTLgvaPLvZ/o6mMQ2rMTdmKKcXIztpkWAwjfTGAGHSDYe/+DI5KKZmt1PSAxjcfzmNKM5/dXznzqt1dTxzFW5Cc13W5SrVxACgUxHt0uWmb3dP268zEU9VEHUJFwFQkwmjJNkepFs0397sPu/qpbTAsKca3f5UICmj+X3mm9W1tvKMD4v2LZn32ppbQN2ZUcCfDmMwWXM0gydxcnrgSgGODpILPp4NAEEqgqURnTt7mfkOqcEBz/IX8qrlD+5+65JxzqiM45tXeNjHo6ADAQMl9V7L8oKm7PR81p761o3D081dTuy6pvV0ek54uV21drFszv/eAm5nTRly+Z2Lbl5as6ZhH69dHDLz1cICuW7xYL2sep/rZyxo+MM/zH7UlXBQU5+QI5uRcmD4TTk6gKGwhOpKFKwiu7WJ8NIsiPyEngbxgSOcUeTjp3DTtRkubWzZx5HftxN6+KimliIhUcnh9mTl+537DO1mMggSEAPwhOKz2PifwuZt8ZWcOq40tGp3V5b72bv/racjvSVLwoW4AJ4KdvxlLRCJgawH8T9t0/qzG2/7Pef5Pp2y4tq00URCwbReuBAoOQfdomBzLIuTVoDiDX5PYNe4gECTs7xO4YJ6FyYSLzUcBV5FbFWDaq4pf8sSOAw+fUNO/Nqe/8EpEpBRAqCqLJbNnnQZ3aCVnw2uUSi/VZDqse3pXs8lvrMr3fvWj1PStxwBgzR03KqALZPw+dv7Vqy/8zNeXXtLXM5h++N6frQNgAxEGvL4LjwCsvR2yHQAqlpdft8xumV1sLfElpj5xaNyRFfUl3C9clIUYoHOkEnkk4zbyNsG0vEhPFjASFzA4w1RWYU4d4TBJ2LZCukDwaUDCVXBdqaq9njUAHv5rhLzGw5sZBHBkBn5fbeKZi1X26BnMGVvBSkINdq7yR0bJ+75B4ffHl65qu/o9q9u+WDmtccZojLbOrjPCL3Y+n/jN2hveE2csuWLFCq2rq+tPgj8FEAHqPecsXdJW7d5syvwZfkOWccYQNCTK/Rp8IR8sApTicBRB40AhW4CTc5BOOYjaAom8i9ExG8NRF5MuQ5AIZ8/zoWfIxaujCoZBkhMxw2cM7/DPXvjshgem1N+Iiv+EGKVA6GzhmChXaAM6O5upFZ1Aa5ck+qOYK6W8GP7cYqcQX6U3nnrnKcs3X3Bay+mXHzwofGPDY6fGc7rZPL8sdfHqk37y4K86Kp554Af/AiAVaWnR2ru6BAAViYCtbYe66KwzF10Qjm/q753yPjNkoy8hRMaVSueM1/iJKkxCfYWFiiINxZyQyQmkCxLxnEBPVCLrKEUFB+NKo4JQaPJwfPLkIDKQ6I8RbMFABKQKAhVhjmdlaOG2bdt2/y33/SeqdMyjdP1FSK8UmNp6nY7FMQI6BBFlATwH4Ln5ZyTOXXPNNe0vPntE6z4wVqsbDJounZ3bxwJTw4+Uv3d1W2FZrd69dcvDa9q7ul4kIqxevZqjc5wIXe6/8OSnD+5PeF/oTWelxi2dGDN1RpYSajIhVRYK+niKtoGhCBzT4SJKDJyTupDnqESC4GH4XVKpg+QjKTUcSNpoLPYhbBQwlHFhg0EAghRnTYa9fBuwe15bGx1zMn+FmBMGN93/r1VaZvjjMju10TOtGnmjdcgTvqqfyJbAuj9KzPo2vi4WZs8/Ph6Mi9TC2BTffmCw8AHLdFw3F9UKbk6XrlKZfMlVtdOsdn/4gpGzF4d+N/2RLb+58/cP/3tHR0f6p9ddp0e6Wtmhwh8ehsBVlUHTm5cKs4IauhN51SwFXV9eQJ9DmEkMFQaQhoSugD05R1WaggbKG5Ff/gEZWryicPFk0rPzu19SJ2Un6YV9Np5GErOr/FhU4UE2Z2NXDqoyoNNY3qkHgL3j43/VjByXmLUEQHEir6n23wojC4wPQWP7oqp3ZZ9L5T2arh7Ni6Jhq+GOTiISAMTMxooZV13zubqHXhheLkVOMa5zKbOQdgogHUd69snDA0c+0lg3L3X68mWXXpj+9uqG2oo/bNk//Ovr1627GwDwHP3+3OYZbWUl6ot61p0jFUJhn0FNa26YOmRkaP+v7tDcchY8qwkKQlHOJfXEcCX9KOU5mjZro0/e9p/XVujIDKfwqD7cW3/6L2+Rq4oc9kzSRddgAfdFPTitNogmn4WBhA0j5E2/mVjmTwYwMr3QJeB1AZ6FZk4Wwze2WNMHLgcbucdC37PywIUHcweuvUcNrvfMWrRy/nBh1rmJZLaKS1uBOEkypCKmCBKMCbb92addBh67/it3yYs+fcvNX/7ix2+4YOWyCz/50as75s5dtgxQeLq7977f9Iyc1lNes/DRLObNXLHsV9+6fe1p927ZdO8Ps0G2y1cHKQSgceVKl8LnnttXVFKWn3p5U800g142ifaWB7C6UNHkRAlUYZI6LyjxiRITp7kFPHZgAruncmwoSnh1NB1vB+QjXV1vRmJOwABY/R1uKiklY4w5TDBo5IiKjaTVHoSM6sJJeTyBEN537hpt2lW/+8LoiHd6NhmTHp/OEpMj4FIwVyiQGwdzExiPpauSwnnspLmNNU8BO6lu+UEAlz310FNnlzfu/eZLe1b1H3z58XX9R199Zd+2bYNlQMXQ0aNRplHvQsMXn+cr0mdVFx8it38GiFxDNzQjFe3R3dS25sry1ps3bTRvmjWr4AWm3PFhpSlANxhmeAVUWsFn+OBJpfGD8TjN9iflRY2B789asoD+e+vuO447g9dNk2gAcGL1bE776m4AN/4tMQOApS0fvOikygZt58sHmOk1WTbrqHOWlLhrLlr8259vtM7e0zNeM77nEWjMZRq3DJdZDdFotn7nzi1DtTI/u3T6zG0Xr77w3KvXbvqZ0bDqZd/z9zwUnRiLB+ecd2nGK4LffO91L995/qdurbvhtLGz3d615PUICFeZfuGuPPBU66tzLrn7R48/evPzJ52MuFLhb/3ipdtKNtxrzKvSREkx8UJWQ5Gex6RjY2kggAoHtCdTgHcwa75vlnH7+xbPGm7v6nrgjfI1f+auFaGz9S/zpa3lx9Y/Hd1020il9pnPFDsfvyH5ycblV934u1+/PCudKVBTSZL//NbT7ms4edXHn9g+dc62Pt7x9IY9LNa9ft9Vn7z2dzKTr2y7oGZJvoA9Hp/vm/WVRYcB4LJzrqmede3NmwuOWb/j8Q3oG45iKl6QM/gBed2soQ2zx3bOW1GcrbVzAkf0EA77ylEOG+nefuwtW7YpVddM2Sl35rRdGypXqcOqtspHtlDIpyXGEy6GbQJREX6QkHgw7YIDsjWsqbOags5OT8XZ9258cXMkcizIfENVOp5W+NMgTEUYOjsZME5Y0yVuAgo33QR89cufqhIuapnh12RKiLKwlA0zyn5MRKk77nnJl8mEaeasOhxKNsUzeTlnYX3R5cpxwKRcmp+cXH1o4Mj3uRV6qqHigl2fmHbXzau+8c2Lqure9/6BV3byLS/1a719eTZtz6Pnr2hM4PloqRye3bI7WzPrZ3Mu/fjW/MSBSxNPdtz03ufvXhmOPQe4Ar5yLqH7WDblAsRgcoV4TkGQF5bGcHlFCE9kJ8EA1jnliJPLHauBxr6JSOS8ed3tfxHoaX9KwrHEFDo7GVq7FBHEcTU7zibDkHrAW41t+esj4VkhrYgFwkGRKSjKFSYVPGWkEdRUlt2y5aBNufHDOLXBdyQTtyunfLYajwWFnY1zIj0Q8nq/UYhlv/H8K3dt+t12tziVkI70eMcaTl9Wp3u1qeL43PC6AwG1f8Naerp8uvLFfAe3PHBXTel//XZpXdhTtejs98kfDk8T984aQJFuMCcnGdkSuofDyQv0TSlMuRpMLuDaBZQHilGsQY3khTSJ1N6YI+Za+vLgL34R/NBRRPFnkfDfWBIYKIx+d4GR614CNbzYzYoWeKq290/N/rdv/HTgynDTZQv2HrI/NHlkyOG5Ef2D5wSeDdYu2rGxL/iFlDTkyJZnqe1C3/fiounGOn/cCof9CPgN+CxN5R0ug0GdFxs27nxRR6F4GoKWA09xEGOHJntP2ffZ6WvOHGHv/WEJ9nfeD4t7wYhBgSCFhFB55GHivVUa7j9NgcdsMIMBREiPOYilBdJCQ1YquPDCE6zE99JpbI2mMSdoYJpfQ9T0dNz96sEPRwD551HwaxKjFGjq4A8DJaVGo0i+uILc2EJVyJyixn+zBBUMYkorkFH/laHM9F/PPPWLsY/+y5cDlparBHSlWxp3nCL8oTO3yrWfWJVylGLeaVQWSNLcpauaH7pvt102p8Q6fDStgsVh8loOudkkr3B86EskxaF9RNw7RdnacmJHJ5Fz9KYHe07FeJGOVfO3YqhTwmFcuFIqDkWcEwge7iGFx0YEfj2s49oigu0qcEawfEC5Any2wITDMJwvCMuO8tnFgScGLN9t3mJPYG+e0s9s3fo4iFT76wjIsch3Y4tG1OXmDvasQWz/T7kzxWC4QAmHO+5P2qk5n8n5bnqoqH5h7ISUSTs3Wj+7anbf0VHXsUt0NxhCenhAppJpKd00zxzeggUfXDm4u9sdV8wKZnK2dGzFpqIpTICBGRaih+KYnHD4wJ4JBKtCSIylYJb6kB88oEajRTR6ZBEuST+NU0lhPxSfAmArhYKU0KFQp0mMEMfOqAPU68CkA2KAVAxKU9BcCbgAz+VpX55he9YKbXrPF5/Buuud40b1Nbl4fRvT2iqBLpCseAH2Kwy6DZkNTwHTHre9C3/ga/raNuAXUBtbtHU9s+m6WQfU8q+9sqN+8QX762orTvWYaW1gXJFijFleH8vbIddfE9BWnLdy+8ZHemY0zimD46RhKw2q4MK0LDjZDAydsOdADJmJfjhJC2RoMMdrYcdjJHM6wpMvg7EEzvBqGHOAHBQY4/iAqWO6IXFGQGEglcRzcR35ggmTA3ZGgDFAuQpHogr7chLdhofthOGW+Njy92/+TkQDIpVNTdqPenvt1yPlf6hSu1IKFDtcMUyZkk6mVfWJytbvWKWf2wf8Fmpji4bWcoWODnX99V3u9cdOevWM1aN6cUlTt7DdJUJIJxUt0pUoCDuV0Za3NGaCgWouxPCpftMW+ayCUlIqcOY6EgGDcHQoj/6Dh8C5A9dRQEHCLkhwlUKe6pSH9dJgfxKfqAJ+O8TRoBS+VaFjXlBCMxWmHI6MXYw604ZjGdDHctCJYCccvDBG2F0cAp9lwXA0mGOcaWCq0W++73uRjWtV+1n2j/5K2uF4gHdiwPUJgJ91LN55EGo9ONoihI52RQQBEFTuNw2F2HMfNKvO/UXLxQ89denHTz03Nurmm6aXWLYLxBOlXHeePfyhKy/dv+HJseUzZlUbjBvwh0IQVgBp3QeZSWL/YAzPvWrDNSqh56MQUoG4DmSHVUaSmt90mJWlN2LF4f2Yu8jCaJ+Dr5Ta4qxTgAIUaYxUsWMjE2PcG/RBy2TAXYWjMRdPaSFgRRizAwYODdhIpCUsDhY2XRnweOa2bb11EQGvtLW18Y6O10/a/6W7JgGsB0NZhNDarojaXYBgj91yOqVfvV72rbucZMmTqFp8R+/2f/uvnuUvXzizufXJ+MAEVZf4liHV9+w1/3b1jk2b8rciN2WSFp082Dsyaeue4aHxoxWzR3rnxaMTKh7N0ALDgyj3Y8gMZAuJpAVpMSo7maaVxKiMNsbMFw56P1KRN19kpSgprUJj5SCHl2DaAIREISPwOK9EVTgDT97GwTSwqboOc5aXwBlJYvBoDuNpHSV+jsqgwKujkNN9rlbqHrkawMvN2MvxBlXKv5nBywxGTtXzuz7LsiMf5BU5wx4pf85c1LkScAACGprPOqn1A1f8ZGnrijFpsyEnNe7t3HDw9P1bn3slgK2/3rZt5x4Aw5fWBi+/Ipj7dgs51dvHQN05kABhn0Pos6zUl0pznuKQrt2SW7i73x+8r2T4wMecWK7qN3UpI1XLcW/DTfkaj/Nd7Q/fOyUUMkNSMyb7Fl8XP5KVV988cYcqT0m6PR9G3enV8E+m4WiEXFoi6wBSAoMxgf40V8UWqWml3P55rGjR3h1b9rU1Nxsd3d32myJGKcXs3q/PZaLn8yw/dA0z4oAJOPnGR/Xmh1cDZB8rwK0loF16gcozLv/8taGiUMVo35Fdzz/x84cBjJy43udal93w6cbo7Y0lDpBXCgVBu1+M4/bDhEubOVYWu/B6DQUD1DXO+temSx7/RJn61F1bU6pNROmTza56oGimGlrxqQe0cz50hxWucNytT58T3/zs+e8/+MtTp6eiatthSRum12L97iQubvZjeVMRCtkcokkJj0nonzhGUspRcvtonnkC+mNaU9PXHn7i2V2vt156nSpBhK3FWnx134f/YIV6LhFD2TwPaZYjah7U5z6+hojsSCTC/lifjjDQLRJK/cllFy/+if6V6c/Irx44Ovee+iO7lvvTavchgfoAMV/YgBzO4cFDeQQthfNqDKQFQ/+QwKhXQ0dZJZq8QuWzRLt3RXFbRRahcsJBK4C+8FzA40NFYhgzp7qhOzoyUYFO3YeBpjI89kICWQKuXeJFiUeHz0eASxiKKeyfymFjv4t6H5enlWksr2mZna7n8/dv373uWCkYEscN8uvWrteCVLbsR59yx0fna1XOdCdZc/8L4499qLWZxIny7B9Ht0soUEtLhKMVKO/uVh0dHfIi//VqTQfEl5bP+8xyLUsv7c6LZxJcmz6iEC5kUWe5eNqpwc5sGIPJfRDcxEVlClsnCzDDtrrn5SxdvzIMb4mFe0dTWBmVmF81JRaylwg5YuhzRDQHNpoR9EoaSJ0RRmLKxuxiA4eTLjb0F/CpZRaYlBhI2Xist4DeqMKiMo6VtZztnRSC513fdI/46eI5M/NrOg7++viagACoN1Cl460e+76wWNePfMpouv8TgAsViTB6k50Mqg28dTxCVxR+3nXtjPzytGFIv0/nmck8btuQxLp0IzKVrUiB4bKhn+DrjQxFkLh1wgM1uxTP7EqiqsaDi6uBA6VnYiFNwti6XTW7MfLqwFH4cDRQBFFRgjF/LbxOL3r3pVHl5cgKhQf7bVy2xIMQBB484MLHddR6OS6Yz2FAYSLuwhFQUpLIwND6XHbP7bGSG3Bgcwr/M/T7S3KO5YH/+PlY/ezNkAKAMUAa4Rl1HScl9180TXpFsU+lJwWFphJ46pCL97EvoshXCWu0E3c792F2sYFDUaCzqAhTlQHs7I7DCppYM1ehp+gs3PLLL6jPfvZXuOfxHFkGcPL0LH71H4uQHhO4a93TmK968Vi3jWrOkFVAZbGOrr48JpIuTqm0oBPQUM4xp4IjmpQwTQZICelIcAGRsTW+MYHnX6pZduEVT/x3+g3bQIhIqUiEYV47YQ3kWyDlGJEA8jlFmmTc6U1D8BycyRy2xxRuC1yKcLACAjrKUt1QFiFlM2zJMtS2lqKlCMiN6Zg7w4NpYYnBVD92PfAkntzskPfkFnACNu98AbHDKWzbPow51lHMKisCEMemfgFZEAgFJT59pg87+gUmkwJNlUBjKcdkUsDr43ByCoYJ9GWAQzGbR9OFQoPPPHPp5J7r24HvvGNNhUqBqLWFf3+i++UznPTJj04yuV9v4NuDZyAXmg1XL4E3uhlXDv4MuulBNK8wraUCFywK48EtCZQWcTQVc1SFdTy130W8dB4e2x/AEWs+pCtQHH0JV57tQyBxGOc1FpDOczh5B/1HUphwHPxkYxKzyy0smWbAD4FFdTr8IRO2JOztz+PFARv7R3KQyQImpUK/0mTA4jirPrD3njt/uegtt5q9WXS2gqOryx1dUv/yAj13yj1HXHVvTodhCVi2Ay3Xgy9HO7CwyIM7JwjlJ4VRVqThgWenkDQ5Wsp0cMuEbukI0zD02jr747O86tN3HDKlSuM7X1ks08NH2ck8CZtKUXDSSMYKKA9y7Ol1UBOyEDY47t+exaDrYmEvx4ySAo7GHfSN2Zjp5LHa68LnU+h3OPqlwkuuYLGMG0Sg9Y1tzN8BjABZsvDsWXfaW185P5gJPDRajNvTfqrQ/bjI7cMZlsTtUybUXA9uXFWG//vEOPYecWAEge9cWA64Cp6ACVO52JyudB8Ynad2qNm6a6ewKtAnr27Yx2ZYGUykFZhTgMkV1m9L4aneLH7xdRsBQ8OP1vmw8WAOO9MFeCHxYW7j4nKJ0/wKfqUwnCMctYHeHMQuLcSfC4W++epA39ffyZZUuRLQJndt6PkvLfzUH3I+lIspcbUzhouTe4F0Bt+aUihbHsBFzSFs2pVEnZ/g8QrsG3Lx250pBE2FsdE0dI+Jymyv9vK2YT3g1SFsjkzPNjbPl8BkGvCqPBIZBz/qjOKpHXl850bC8LCJnl6JM1YJNIW8aA5puNLn4v80KSyq1pE3NWRDBmqrdcwKEqabCqvKSlBUUbsVeBtdm28JLQC6QMXBwL5EkUX9pTnkkjaU8qO0VMfpPgtewfHMq3nsT2Qxv0THKWUm4nmBZ/YUMLdMwxlVHvT2ZzC70oc1M/rw813DKFM9+Mp7bUSzDIYoYDiax392ZiA5w8//08UD9wRR1SgRT3gQzxDav5nBZ2/mWOQoHMgxKKlQ5mEwpURfHPAyDsBVtTKNk4VY1Qk8+I4S09UFoQBQpvh78YGea99Tb1XkLFOGQ4zlCxKDh1xASQzmXEzkgEqLY/OoA1sqnF9r4LcvZlC8iqPBq+PwiItLpydxX+8L+OiiOEq4QCYnsX+sgHXP5dFcbGJeNeGuDo4rPpjFrj0aTlqg4A1x/PhnFqRwkJES8+s4QgGOiaMuTKVQYgAjOQaDM3C48HPXBd5k29X/AmoNwLCzK95vWP++eUxSz7iUBwYltvU5GHUk+gsCE6kCLqgzYXKJaAHQmERLLXB2jYk7O1M4knUQ8nKkExJtFTtxaiAKuyCxZTCHdV1ptE4z8N6ZChWWQGFQx8NbGK66JI75J+dx+6PAwW4HJYUMFlRy7DEM9Pi9KK03AE4YSgE+UsgJgs4llJN54yXB3xMdgGgDeEd//4+D9fVnezLOpSoJUeaXfF6JiYGExLwSA4wI/SlAZxz1foWkzXFKHcEyDfxgQwJfOi+EI0mFcp8H9cUa7t2RxtZeF1csMBH2SkxkNAymFMqKJNx9Ptz4QyARc7AgnsaH5xfgD5vIcwPZhMCLm9O4Ow9cUwc0BIHemIRPAwgSDI4GvPMSc4IcRUqhYvbsG+ZXmtlyQyGgMdU76iKadJFxGBqKCSlbotQkEAhKAQVbYlkDsLzCwrefSWEo56JljolfbstiVx9w2TwL00ok4hkgpxhMk2NGhQarCGgYtPH94hy+vszFjEYfKqZ5UR8kNCgbHywXOD/g4o4ewmBWwdUZ0q4i7vPiqC+8E3gXJOY45GqAdzz55MjlS2b/tKmYPjerRNqjeWXkbYbqAGEsLZFzCQlHQAqCVASPh6EAwllNEiN5jpm1Gjp25JBKAlefwlFeypBzNFSXCaQKEiUC2D4mMSsxgU8sAVDkR55rYDkH6lAK2dECXFuCWwxnVgBF3MXd4xyXFkuEdLBJndmPxLybCO+SxABAByAjAPttqiRyIC939SW40RjiTlMJV0RAXwKYyCskHIlSS0HTXHANSKcEhlIK1eUc0biEk8zjyqUM02p1SADJjIt4BghqClkGzEzH8IllJpyaYtiSgR2Mw9k2hXRfBl6N4DMYAibDQIaQsH3QwbE36YqF1VXYGazZMrF3ZZ+MgL2bW2tUOwA6sDnVYfvP25Gnx54/yvWhOKOeCQ4OQokpoaRCVBJixNAz5mJalQ7TIoAIuqtQWaHjQIxBkgbGNYR8DCFTQWgaRvpS+EidA1EXBssLUG8SKqWQERwpaIhmBDKOQG8UGMx4MCYMVHh8mJRcDgRL6b6s9UNCu2ztbGHvliqdgFQAoW/P2ANEFy6fO3f1gbHkv1PBnpmUUImCYilb4rwyE0MxBq8uYJgGErYLDwcmMkDCMeDXFLhmwGsBpDkIBSRe6s/hFMrBU+9HdiCB7MEMfCSRyiv4NcI+6cemoQw+UikwmmXISAnFBCylXCMU0B+w1YbOzZ33H2vT73L/EZuxVAugKaVYtKh687wSHiYF7I67tCfuYmZIw9lNXhR7FeZV6JgYd3BgTGBBvRen1DKU+wQWTPcgb0sQJEaGshhNCIjxDFqma7DzEpnDGWRjDsYywMtTCnvTCl/qyWNuvY6GGg1+5qIAQiKXkauqPFp/SdWOr/XEP6oiEaL2Y1mEf8gutdaWFhAgVxkjP2xtMMpKvYbUSJHFgPoAh6URZhfr0BjQP5yFIwjhkAdNNV6c1uiDzghjEzkk4g5Kwzp6xwTKlAMfU8iM2CiMOQjrwJim44a4BysHDHysiWF1rcSeww4YEaYKeTUvaKGvtGrySbP0CjY5OLKmu/21wv67TkxbWxu/pavLXXrK/OXLS+WlQ1NSThYki9sKVQZhab2JaEYinpPweglK5ygoIJ/KoX8wD93ksB0B0wKiCRs+L0PaVij3AvlJF0WZAnaZOu6KcXxrgDCa03FlHcf1dYStu2zYkiOaFzjFyxQqG9kX9o5lgxb1fR1gHR1/LOy/q8REIhG2fn2HVLXnFbdV478XljJtPOlgT6JAjAjNRRoCBkHZLjQIFGyCaTIQE7BcF5msi1zagRAKrkMIBDhGRvLI5AGVVXixz8FPRhjunDDw/WQAUcPEt+a7+HaDix09OYw6hJTjYobHgFVey/5tYEpVamqaz7YXtQOyra3tNT7eTePL1qIdRBH64lm//9UFM8zG53fFxQujNh/KC1TqHAtLOXQGDGQkigKA3xGYSil4fAYsg0EzFIYnbIQDx3bXMKmBGRzzSiU6+wzsKmgYhQETAld7k/hck0LQFtjRq5BXHGW6B9zy4VGX4zd9OWSVI86r9WpTTvSDBGxuHu94LQ3zbhFDEQDUrui605vvfn8jv2jP4bi7Y6ig7Yg50EBYGCDMrzExlVWIuQwTMQlyBWIZBc1HSOYU9kYlHCVQ6nJMCzJkMwKjMQlJQFmlF15bYrkXSNgcz014kN6VQwgMPi/BIT8O2xr2pCWOujbCBqHBb7EZIUKxl1YrXPT1tV2P5I63hKh3gxha3wa2BgqfmTr57o80GZensll3z0BBe2migJijUGMQTq0yUFaqo+9gAbE8YBcEiqtNHIk5sHSCUhITcRuSNFRWH8u2J7MCjBGiWYnxpMTcMFBdxNEXJSQcPzZkTEBJCFdhqiBgcRc6I1R5NdiKoczLmMdUoqxIm/api5MfoYex7kQ9+x0npg1gazogLj1l/s2XLmSXS6acl/Y7+pYJG30ZAZ0I072ExTO9GE8A6YzA3CCDaZowIMEUwKEQ1CXKfRpG0kCNn8HjYQAEfF6FogChhBOCfsJAAiApUa5LlIUZpgoMeedYR3nYItiKIy0USiwNOcEwlpFUU+Zgppn+AhC5a/36dkEEekeNb1tbG1/f06OFp58x7SQre3MukRXrX8xq28dc7I4LSAA+prCkwoDHyzEw5mB+rYEiD6HcJ6EUIeBh0KCQtwlzwxznT+cQeYlsTsEwANcBoBhm1OsYyyvEsgoBU6LGTyj1cBSZDJbG4DcYLE4otQgBTghrEvUBoDeq2EhUipODclbr/N9/iAiqpaWFv6PENI+PE2bOtM8pS398YTHzxFKOaykpEq5wc650ieBqSsmaClMK59iOLzBSRQEOhxiiWYKuAY5LUOL49hemwEihkBZwHYZoihBNE2xbYSzJkXYADz8WjHAolFoK9QGGWp+ugiapYotLr06CiNyQAXdFA3MdKVyRyojWCufTQBvvbO2S77C77gIRKV8hXVkoqLihaWaRwbSBtKsZnGm2gNYQ0NjCSp31DdsUsggjcUm6xgQJuMoVbiyjXCGkm3eEK5ly83lyCy5czpWbzwrX5Mo1uHAPjAjXdYXr1+BGc3AdCVfn5JZ7uGtyKA8HcYACXLD5IcYtXdMsnWnFHk0zFcxsWvAKQy3xFO+vYu2Q76iNae+CC4CeT9Nnqiua1jZh+NRhjopJljuJDKGkEL6ldZ6zQn6dssIplS55q8OaOjSi+PwaA2FdYCjhImsr6ARokoOBoGsEoQBHAiYBRZbCWExBg0LQAGyhwasDXpPB0oC+tIKCixJLUwfz7HBjyDhcHvQPJwzTyHjZIT/PZvRQqLfCCu89NRsb7ep6m892+Htiz/qIsWEkSuX7B8uTR476ZjWU4OXD2aW1ftfLAXSPOxgUEu+t0jGVBkz9WFQaywM6Z9AhUeoFuicFolkXxSaDzhnCJuAA4OAYLhivDhZEoi6s0/1X33Goe80C+2898uHdIoYUgI62NrZ3fJzau7pOHFd4G89d+N8iArBOgJUD6oaWFgKAifJytbe5WZ1ob/mHSwyOk7Y2cmwuaxHB2s5O1nr8y87j761/dtKfH+/EG6O7vFw1d3QoRID2Y6vnv1mH/3+GWXG8KNc5MAAAAABJRU5ErkJggg==';
  lobster.id = 'cb-lobster';
  hud.appendChild(lobster);


  // ── 应用设置外观 ──────────────────
  function applyAppearance() {
    hud.style.opacity = settings.opacity;
    hud.style.transform = `scale(${settings.scale})`;
    hud.style.transformOrigin = 'top right';
  }
  applyAppearance();

  // ── 设置面板 ──────────────────────
  const panel = document.getElementById('cb-settings-panel');
  panel.style.display = 'none';

  document.getElementById('cb-voice-btn').addEventListener('click', e => {
    e.stopPropagation();
    settings.voice = !settings.voice;
    document.getElementById('cb-voice-btn').textContent = settings.voice ? '🔊' : '🔇';
    document.getElementById('cb-s-voice').checked = settings.voice;
    saveSettings(settings);
    if (settings.voice) speak('测试');
  });

  document.getElementById('cb-settings-btn').addEventListener('click', e => {
    e.stopPropagation();
    settingsOpen = !settingsOpen;
    panel.style.display = settingsOpen ? 'block' : 'none';
  });

  document.getElementById('cb-s-threshold').addEventListener('input', function() {
    settings.threshold = +this.value;
    document.getElementById('cb-s-threshold-v').textContent = this.value + '%';
    saveSettings(settings);
  });
  document.getElementById('cb-s-opacity').addEventListener('input', function() {
    settings.opacity = +this.value;
    document.getElementById('cb-s-opacity-v').textContent = Math.round(this.value*100) + '%';
    hud.style.opacity = settings.opacity;
    saveSettings(settings);
  });
  document.getElementById('cb-s-scale').addEventListener('input', function() {
    // 拖动时只更新数字显示，不实时缩放
    document.getElementById('cb-s-scale-v').textContent = (+this.value).toFixed(1) + 'x';
  });
  document.getElementById('cb-s-scale').addEventListener('change', function() {
    // 松开后才应用缩放
    settings.scale = +this.value;
    document.getElementById('cb-s-scale-v').textContent = (+this.value).toFixed(1) + 'x';
    hud.style.transform = `scale(${settings.scale})`;
    hud.style.transformOrigin = 'top right';
    saveSettings(settings);
  });
  document.getElementById('cb-s-voice').addEventListener('change', function() {
    settings.voice = this.checked;
    document.getElementById('cb-voice-btn').textContent = settings.voice ? '🔊' : '🔇';
    saveSettings(settings);
    if (settings.voice) speak('测试');
  });

  // ── 拖动 ──────────────────────────
  let dragging = false, ox = 0, oy = 0;
  document.getElementById('cb-header').addEventListener('mousedown', e => {
    if (e.target.tagName === 'BUTTON') return;
    dragging = true;
    ox = e.clientX - hud.offsetLeft;
    oy = e.clientY - hud.offsetTop;
    hud.classList.add('dragging');
    e.preventDefault();
  });
  document.addEventListener('mousemove', e => {
    if (!dragging) return;
    hud.style.left = Math.max(0, Math.min(window.innerWidth - hud.offsetWidth, e.clientX - ox)) + 'px';
    hud.style.top = Math.max(0, Math.min(window.innerHeight - hud.offsetHeight, e.clientY - oy)) + 'px';
    hud.style.right = 'auto';
  });
  document.addEventListener('mouseup', () => { dragging = false; hud.classList.remove('dragging'); });

  // ── 最小化 ────────────────────────
  document.getElementById('cb-minimize').addEventListener('click', () => {
    minimized = !minimized;
    document.getElementById('cb-minimize').textContent = minimized ? '+' : '−';
    ['cb-body','cb-ca','cb-footer','cb-settings-panel'].forEach(id => {
      document.getElementById(id)?.classList.toggle('minimized', minimized);
    });
    if (minimized) { settingsOpen = false; panel.style.display = 'none'; }
  });

  // ── CA识别 ────────────────────────
  function getCA() {
    const m = location.href.match(/(0x[a-fA-F0-9]{40})/);
    return m ? m[1] : '';
  }

  // ── 读取GMGN持仓 ──────────────────
  function readGMGN() {
    const holders = [];
    const bars = document.querySelectorAll('.rounded-22px.bg-text-200.absolute[style*="width"]');
    bars.forEach((bar, idx) => {
      const pct = parseFloat(bar.style.width);
      if (isNaN(pct) || pct <= 0) return;
      let address = `gmgn_${idx}`, el = bar;
      for (let i = 0; i < 10; i++) {
        el = el.parentElement; if (!el) break;
        const a = el.querySelector('[data-inserted-address]') || (el.hasAttribute('data-inserted-address') ? el : null);
        if (a) { address = (a.getAttribute('data-inserted-address') || a.textContent).toLowerCase(); break; }
      }
      let amount = '', rowEl = bar;
      for (let i = 0; i < 8; i++) {
        rowEl = rowEl.parentElement; if (!rowEl) break;
        const p = rowEl.querySelector('.bg-panel-200');
        if (p?.previousElementSibling) { amount = p.previousElementSibling.textContent.trim(); break; }
      }
      holders.push({ address, pct, amount });
    });
    return holders.slice(0, TOP_N);
  }

  // ── 读取DeBot持仓 ─────────────────
  function readDeBot() {
    const holders = [];
    document.querySelectorAll('.MuiLinearProgress-bar1Determinate,[class*="bar1Determinate"]').forEach((bar, idx) => {
      const m = (bar.style.transform||'').match(/translateX\(-?([\d.]+)%\)/);
      if (!m) return;
      const pct = Math.max(0, 100 - parseFloat(m[1]));
      if (pct <= 0) return;
      const container = bar.closest('.MuiStack-root,[class*="modernize"]');
      let address = `debot_${idx}`, amount = '';
      if (container) {
        const parent = container.closest('[class*="modernize-1v7pzty"],.MuiStack-root');
        if (parent) {
          const a = parent.querySelector('[class*="modernize-gprpy4"],[class*="gprpy4"]');
          if (a) address = a.textContent.trim();
          parent.querySelectorAll('*').forEach(el => {
            if (!el.children.length && /\$[\d,.]+/.test(el.textContent)) amount = el.textContent.trim();
          });
        }
      }
      holders.push({ address, pct, amount });
    });
    return holders.slice(0, TOP_N);
  }

  function readHolders() { return PLATFORM === 'gmgn' ? readGMGN() : readDeBot(); }

  // ── 对比快照，检测出货 ────────────
  function compare(current) {
    const selling = new Map();
    current.forEach((h, idx) => {
      const prev = snapshot[h.address];
      if (prev && prev.pct > 0) {
        const drop = (prev.pct - h.pct) / prev.pct * 100;
        if (drop >= settings.threshold) {
          const rank = idx + 1;
          selling.set(h.address, rank);
          alertCount++;
          document.getElementById('cb-alert-count').textContent = alertCount;
          document.getElementById('cb-status-dot').className = 'alert';
          speak(rank);
          chrome.runtime.sendMessage({ type: 'ALERT', alert: { address: h.address, drop: drop.toFixed(1), rank, ca: currentCA, source: PLATFORM, time: Date.now() } }).catch(()=>{});
        }
      }
      snapshot[h.address] = { pct: h.pct };
    });
    return selling;
  }

  // ── 渲染列表 ──────────────────────
  function render(holders, selling) {
    const body = document.getElementById('cb-body');
    if (!holders.length) { body.innerHTML = '<div class="cb-empty">未找到持仓数据</div>'; return; }
    body.innerHTML = holders.map((h, i) => {
      const isSelling = selling.has(h.address);
      const prev = snapshot[h.address];
      const delta = prev ? (prev.pct - h.pct) / (prev.pct||1) * 100 : 0;
      const isWarning = delta >= 5 && delta < settings.threshold;
      const barW = Math.min(h.pct * 4, 100);
      return `<div class="cb-row${isSelling?' selling':''}" title="${h.address}">
        <span class="cb-rank">${i+1}</span>
        <div class="cb-bar-wrap"><div class="cb-bar${isSelling?' selling':isWarning?' warning':''}" style="width:${barW}%"></div></div>
        <span class="cb-pct${isSelling?' selling':isWarning?' warning':''}">${h.pct.toFixed(2)}%</span>
        <span class="cb-delta${isSelling||isWarning?' show':''}">${isSelling||isWarning?'−'+Math.abs(delta).toFixed(1)+'%':''}</span>
      </div>`;
    }).join('');
  }

  // ── 主循环 ────────────────────────
  function tick() {
    const ca = getCA();
    if (ca !== currentCA) {
      currentCA = ca; snapshot = {}; alertCount = 0; voiceCooldown = {};
      document.getElementById('cb-alert-count').textContent = '0';
      document.getElementById('cb-status-dot').className = '';
      document.getElementById('cb-ca-val').textContent = ca ? ca.slice(0,8)+'...'+ca.slice(-6) : '未检测到代币';
    }
    if (!ca) return;
    const holders = readHolders();
    if (!holders.length) return;
    document.getElementById('cb-status-dot').className = 'active';
    const selling = compare(holders);
    render(holders, selling);
    if (selling.size > 0) {
      document.getElementById('cb-status-dot').className = 'alert';
      hud.classList.add('alerting');
      setTimeout(() => hud.classList.remove('alerting'), 3000);
    }
  }

  // ── 启动 ──────────────────────────
  function waitAndStart() {
    const check = setInterval(() => {
      const ok = PLATFORM === 'gmgn'
        ? document.querySelectorAll('.rounded-22px.bg-text-200.absolute').length > 0
        : document.querySelectorAll('.MuiLinearProgress-bar1Determinate').length > 0;
      if (ok) { clearInterval(check); isRunning = true; setInterval(tick, 1000); }
    }, 500);
  }

  let lastURL = location.href;
  new MutationObserver(() => {
    if (location.href !== lastURL) {
      lastURL = location.href; snapshot = {}; currentCA = ''; voiceCooldown = {};
      if (!isRunning) setTimeout(waitAndStart, 1500);
    }
  }).observe(document.body, { childList: true, subtree: true });

  waitAndStart();
})();
